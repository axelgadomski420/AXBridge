# AXBridge

**Komunikator nowej generacji + Studio Kreatywne + Asystent AI**  
Zbudowany z myślą o maksymalnej dostępności (niewidomi, niesłyszący, osoby z ograniczeniami ruchowymi).

Tagline: **Połącz wszystkich. Stwórz wszystko.**

## Co to jest

AXBridge to niezależna platforma, która łączy:

1. **Komunikator** (czat E2E, połączenia audio/wideo, grupy)
2. **Studio Kreatywne** (muzyka, teledyski, obrazy, głos, 3D)
3. **Asystenta AI** z tool use
4. **Maksymalną dostępność**:
   - Odbieranie wiadomości kodem Morse’a przez wibracje
   - Wsparcie czytników ekranu (VoiceOver / TalkBack)
   - Sterowanie głosem
   - Tłumaczenie wspomagane języka migowego (avatar + tekst)
   - Wysoki kontrast, duże czcionki, tryb uproszczony
5. **Wewnętrzny system roboczy** (workspace) — projekty, notatki, biblioteka mediów, generacje

Nazwa poprzednia (AL2100) została zastąpiona przez **AXBridge**.

## Struktura folderu

```
AXBridge/
├── README.md
├── docs/
│   ├── VISION.md
│   ├── ACCESSIBILITY.md
│   ├── CALLS_AND_CHAT.md
│   └── ARCHITECTURE.md
├── security/
│   └── E2E_AND_PRIVACY.md
├── database/
│   └── schema.sql
├── axcode/
│   ├── app.ax                 ← główna aplikacja w AXCode
│   ├── screens/
│   └── components/
└── design-system/
```

## Najważniejsze dokumenty

1. `docs/VISION.md` — pełna wizja
2. `docs/ACCESSIBILITY.md` — dostępność (Morse, migowy, screen reader…)
3. `docs/CALLS_AND_CHAT.md` — czat + FaceTime-style calls
4. `axcode/app.ax` — przykładowa aplikacja napisana w AXCode
5. `database/schema.sql` — baza danych

Projekt niezależny. Żadnych fałszywych powiązań z innymi firmami.
