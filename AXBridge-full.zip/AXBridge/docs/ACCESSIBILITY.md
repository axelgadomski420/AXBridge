# AXBridge — Dostępność (priorytet numer 1)

AXBridge ma być jednym z najbardziej dostępnych komunikatorów na rynku.

## 1. Wsparcie dla niewidomych i słabowidzących

- Pełna kompatybilność z VoiceOver (iOS) i TalkBack (Android)
- Semantyczne role i etykiety na każdym elemencie
- Opisy obrazów generowane automatycznie + możliwość własnego opisu
- Nawigacja gestami i klawiaturą
- Sterowanie głosem („Napisz do Ani”, „Odbierz połączenie”, „Przeczytaj ostatnią wiadomość”)
- Wysoki kontrast + tryb maksymalnego kontrastu
- Skalowanie czcionek do 200%+ bez łamania layoutu
- Zmniejszenie animacji (prefers-reduced-motion)

## 2. Wsparcie dla niesłyszących i słabosłyszących

### Wiadomości jako kod Morse’a przez wibracje
- Użytkownik może włączyć „Odbieraj wiadomości wibracjami Morse”
- Krótka wiadomość tekstowa jest zamieniana na sekwencję wibracji (kropka = krótka, kreska = długa)
- Możliwość powtórzenia sekwencji
- Wibracje są konfigurowalne (siła, szybkość)
- Działa w tle (z ograniczeniami systemu)

### Napisy na żywo
- W połączeniach audio/wideo automatyczne napisy (speech-to-text)
- Napisy można zapisać jako notatkę

### Tłumaczenie języka migowego (wspomagane)
Uwaga techniczna (uczciwość):
Pełne, płynne, dwukierunkowe tłumaczenie ciągłego języka migowego w czasie rzeczywistym nadal jest problemem badawczym i nie jest w pełni rozwiązane na poziomie produkcyjnym w 2026 roku.

W AXBridge stosujemy podejście **wspomagane**:
- Użytkownik może włączyć „Avatar migowy”
- System pokazuje uproszczonego avatara wykonującego znaki na podstawie tekstu (text-to-sign)
- W drugą stronę: użytkownik może nagrać krótki gest / użyć klawiatury migowej → system proponuje tekst (sign-to-text, z potwierdzeniem)
- W połączeniach wideo: napisy + opcjonalny avatar
- To realna, użyteczna pomoc, a nie obietnica magicznego pełnego tłumacza

## 3. Osoby z ograniczeniami ruchowymi
- Pełne sterowanie głosem
- Wsparcie przełączników (Switch Control)
- Duże cele dotykowe (min. 48×48 pt)
- Tryb jednej ręki
- Opóźnienie długiego naciśnięcia konfigurowalne

## 4. Tryby dostępności (szybkie przełączanie)
- Tryb standardowy
- Tryb wysokiego kontrastu
- Tryb uproszczony (mniej elementów, większe przyciski)
- Tryb Morse (wibracje)
- Tryb tylko głos
- Tryb napisów zawsze włączonych

## 5. Testowanie
- Testy z rzeczywistymi użytkownikami korzystającymi z czytników ekranu
- Testy z osobami niesłyszącymi
- Automatyczne audyty WCAG 2.2 AA / AAA gdzie to możliwe
- Raport dostępności publiczny

Dostępność nie jest listą checkboxów. Jest częścią DNA AXBridge.
