# AXBridge — Ultimate Accessibility System
## Najbardziej dostępny komunikator / społeczność / workspace

Dostępność nie jest modułem. Jest rdzeniem całego systemu.
Każda funkcja (czat, połączenie, studio, asystent, biblioteka) musi działać w każdym profilu dostępności.

---

## 1. Profile dostępności (użytkownik wybiera i łączy)

Użytkownik może mieć kilka zapisanych profili i przełączać je jednym gestem / komendą głosową:

- **Niewidomy / słabowidzący**
- **Niesłyszący / słabosłyszący**
- **Ruchowy** (ograniczenia motoryczne)
- **Poznawczy** (łatwiejszy odbiór informacji)
- **Wielozmysłowy** (kombinacje)
- **Opiekun** (tryb wspomagający inną osobę)
- **Niestandardowy** (własne ustawienia)

Profil zapisuje:
- sposób odbierania wiadomości
- sposób nawigacji
- wielkość celów dotykowych
- poziom uproszczenia interfejsu
- preferencje wibracji / dźwięku / napisów / avatara
- język i preferencje TTS/STT

---

## 2. Niewidomi i słabowidzący — maksymalny poziom

### Nawigacja i odczyt
- Pełna, przetestowana obsługa VoiceOver + TalkBack + brajlowskich wyświetlaczy
- Każdy element ma sensowną etykietę i rolę
- Kolejność fokusowania logiczna i przewidywalna
- Skróty gestów i klawiatury
- Opisy obrazów automatyczne + możliwość własnego długiego opisu
- Opisy wideo (audio description) gdy dostępne

### Tryb tylko głosowy (Voice-Only Mode)
- Cała aplikacja sterowana głosem
- „Przeczytaj nowe wiadomości”
- „Odpowiedz Ani: będę za 10 minut”
- „Zadzwoń do Piotra wideo”
- „Włącz tryb Morse”
- Potwierdzenia głosowe każdej akcji

### Sonifikacja i wskazówki przestrzenne
- Różne dźwięki dla różnych typów powiadomień
- Spatial audio (kierunek, z której strony przyszła wiadomość/połączenie)
- Dźwiękowe mapowanie list i pozycji

### Brajl
- Pełne wsparcie wyświetlaczy brajlowskich
- Skróty brajlowskie

### Wizualne
- Skalowanie czcionek do 300%
- Maksymalny kontrast
- Tryb odwróconych kolorów
- Zmniejszenie / wyłączenie animacji
- Grube kursory i wskaźniki fokusu

---

## 3. Niesłyszący i słabosłyszący — maksymalny poziom

### Wiadomości i powiadomienia
- **Kod Morse’a przez wibracje** (konfigurowalna szybkość i siła)
- Własne wzorce wibracji dla:
  - nowa wiadomość
  - połączenie przychodzące
  - wzmianka / mention
  - pilne
  - wiadomość od ulubionej osoby
- Wizualne powiadomienia (pulsowanie krawędzi, kolorowe flash’e, ikony)
- Możliwość przypisania koloru do konkretnej osoby

### Połączenia
- Napisy na żywo (wysoka jakość speech-to-text)
- Zapis napisów jako notatki
- Wizualny wskaźnik mówienia (kto teraz mówi)
- Avatar języka migowego (text → znaki)
- Możliwość pokazywania własnego wideo + napisów jednocześnie

### Język migowy (wspomagany — uczciwe podejście)
- Text-to-Sign: avatar wykonuje znaki
- Sign-to-Text: użytkownik pokazuje gesty / korzysta z klawiatury migowej → system proponuje tekst do potwierdzenia
- Biblioteka najczęściej używanych znaków i fraz
- Możliwość zapisywania własnych skrótów migowych
- W połączeniu: napisy + avatar jednocześnie

Pełne ciągłe tłumaczenie dwukierunkowe języka migowego w czasie rzeczywistym nadal nie jest rozwiązane na poziomie produkcyjnym. AXBridge daje najlepsze obecnie możliwe wsparcie wspomagane.

---

## 4. Ograniczenia ruchowe (motoryczne)

- **Switch Control** / zewnętrzne przełączniki
- **Eye Tracking** (gdy urządzenie wspiera)
- Dwell click (kliknięcie przez przytrzymanie wzroku/kursora)
- Sterowanie głosem pełne
- Sticky Keys / Slow Keys
- Tryb jednej ręki (lewa / prawa)
- Cele dotykowe minimum 48–56 pt, możliwość jeszcze większych
- Opóźnienie długiego naciśnięcia regulowane
- Gesture alternatives (każdy gest ma alternatywę przyciskową lub głosową)
- Możliwość sterowania tylko przyciskami wolumenu / słuchawkami

---

## 5. Trudności poznawcze / neuroróżnorodność

- **Tryb uproszczony** — mniej elementów, jasna hierarchia, duże przyciski
- **Tryb skupienia** — ukrywa wszystko poza aktualną rozmową/zadaniem
- Czcionki przyjazne dla dysleksji + zwiększone odstępy
- Możliwość ograniczenia liczby powiadomień
- Krok-po-kroku przewodniki (onboarding i nowe funkcje)
- Przewidywalna nawigacja (zawsze te same miejsca na te same rzeczy)
- Potwierdzenia ważnych akcji (usunąć, wysłać, zadzwonić)
- Kolorowe etykiety i ikony wspierające zrozumienie

---

## 6. Funkcje systemowe „OS w OS” z dostępnością

AXBridge ma wewnętrzny workspace, który też jest w pełni dostępny:

- Notatki głosowe → automatyczna transkrypcja
- Notatki tekstowe z odczytem
- Biblioteka mediów z opisami
- Projekty kreatywne z pełnym wsparciem czytników
- Asystent, który zna aktywny profil dostępności i dostosowuje odpowiedzi (krótsze zdania, więcej struktury, unika metafor jeśli użytkownik tego chce)

### Profil Opiekuna
- Osoba wspierająca może (za wyraźną zgodą) pomagać w zarządzaniu kontaktami, przypomnieniami, ustawieniami dostępności
- Pełna transparentność — użytkownik widzi co opiekun robi
- Można w każdej chwili cofnąć dostęp

### SOS / Nagły wypadek
- Szybkie wezwanie pomocy
- Automatyczne wysłanie lokalizacji + wiadomości do wybranych kontaktów
- Działa z poziomu gestu / głosu / przełącznika
- Dostępne nawet gdy telefon jest zablokowany (w granicach systemu)

---

## 7. Personalizacja i uczenie się preferencji

- System zapamiętuje, jak użytkownik najchętniej odbiera wiadomości
- Proponuje optymalizacje („Często włączasz Morse wieczorem — ustawić automatycznie?”)
- Można eksportować i importować profil dostępności (przydatne przy zmianie telefonu)

---

## 8. Testowanie i standardy

- WCAG 2.2 AA jako minimum, dążenie do AAA tam gdzie to ma sens
- Regularne testy z użytkownikami niewidomymi, niesłyszącymi, z ograniczeniami ruchowymi i poznawczymi
- Publiczny raport dostępności
- Kanał feedbacku dostępności z wysokim priorytetem

---

## Podsumowanie podejścia

AXBridge nie „dodaje dostępność”.
AXBridge jest projektowany od pierwszego piksela i pierwszej linii kodu jako aplikacja, która ma działać świetnie dla osób z różnymi niepełnosprawnościami.

To jest ultimate komunikator + społeczność + workspace właśnie dlatego, że nikt nie jest wykluczony z podstawowych funkcji: rozmowy, tworzenia, bycia częścią społeczności.
