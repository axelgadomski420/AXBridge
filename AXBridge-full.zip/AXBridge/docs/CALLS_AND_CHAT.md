# AXBridge — Czat i Połączenia

## Czat End-to-End Encrypted
- Protokół oparty na Signal Protocol (Double Ratchet + X3DH)
- Serwer widzi tylko ciphertext
- Wiadomości: tekst, obraz, wideo, audio, projekt AXBridge, piosenka
- Grupy z Sender Keys / MLS
- Forward secrecy + safety numbers

## Połączenia audio i wideo
- WebRTC
- Sygnalizacja przez własny serwer (lub LiveKit / SFU)
- E2E gdzie to możliwe (insertable streams / 1:1)
- Napisy na żywo (speech-to-text)
- Opcjonalny avatar migowy
- Możliwość nagrywania (za zgodą obu stron)
- Przełączanie kamera / głośnik / wyciszenie

## Integracja z dostępnością
- Wiadomość przychodząca → opcjonalnie wibracje Morse
- W połączeniu: napisy + avatar
- Pełne wsparcie czytników ekranu na kontrolkach połączenia
- Sterowanie głosem („Odbierz”, „Zakończ”, „Wycisz”)
